const request = require("supertest")
const app = require("../app")
const cache = require("../configs/cache")

describe("Sistema de Cache", () => {
  let token

  beforeAll(async () => {
    // Limpar cache antes dos testes
    cache.flushAll()

    // Fazer login para obter token
    const loginResponse = await request(app).post("/login").send({
      usuario: "admin",
      senha: "123456",
    })
    token = loginResponse.body.token
  })

  afterEach(() => {
    // Limpar cache após cada teste
    cache.flushAll()
  })

  test("Primeira requisição deve vir do banco de dados", async () => {
    const response = await request(app).get("/clientes").set("Authorization", `Bearer ${token}`)

    expect(response.status).toBe(200)
    expect(response.body.source).toBe("database")
  })

  test("Segunda requisição deve vir do cache", async () => {
    // Primeira requisição
    await request(app).get("/clientes").set("Authorization", `Bearer ${token}`)

    // Segunda requisição
    const response = await request(app).get("/clientes").set("Authorization", `Bearer ${token}`)

    expect(response.status).toBe(200)
    expect(response.body.source).toBe("cache")
  })

  test("Cache deve ser invalidado após criação de cliente", async () => {
    // Primeira requisição para popular cache
    await request(app).get("/clientes").set("Authorization", `Bearer ${token}`)

    // Criar novo cliente (deve invalidar cache)
    await request(app).post("/clientes").set("Authorization", `Bearer ${token}`).send({
      nome: "Teste Cache",
      sobrenome: "Usuario",
      email: "cache@teste.com",
      idade: 30,
    })

    // Próxima requisição deve vir do banco
    const response = await request(app).get("/clientes").set("Authorization", `Bearer ${token}`)

    expect(response.status).toBe(200)
    expect(response.body.source).toBe("database")
  })
})
