const request = require("supertest")
const app = require("../app")

describe("Endpoints da API", () => {
  let token

  beforeAll(async () => {
    // Fazer login para obter token
    const loginResponse = await request(app).post("/login").send({
      usuario: "admin",
      senha: "123456",
    })
    token = loginResponse.body.token
  })

  describe("GET /", () => {
    test("Deve retornar mensagem de boas-vindas", async () => {
      const response = await request(app).get("/")

      expect(response.status).toBe(200)
      expect(response.body.message).toContain("Bem-vindo")
      expect(response.body.status).toBe("Servidor funcionando corretamente")
    })
  })

  describe("Endpoint /usuarios", () => {
    test("GET /usuarios deve funcionar", async () => {
      const response = await request(app).get("/usuarios")

      expect(response.status).toBe(200)
      expect(response.body.data).toBeDefined()
      expect(Array.isArray(response.body.data)).toBe(true)
    })

    test("POST /usuarios deve criar usuário", async () => {
      const novoUsuario = {
        usuario: "teste_user_" + Date.now(),
        senha: "123456",
      }

      const response = await request(app).post("/usuarios").send(novoUsuario)

      expect(response.status).toBe(201)
      expect(response.body.message).toBe("Usuário criado com sucesso")
      expect(response.body.data.usuario).toBe(novoUsuario.usuario)
    })
  })

  describe("Endpoint /clientes (autenticado)", () => {
    test("GET /clientes sem token deve retornar 401", async () => {
      const response = await request(app).get("/clientes")

      expect(response.status).toBe(401)
      expect(response.body.error).toBe("Token de acesso requerido")
    })

    test("GET /clientes com token deve funcionar", async () => {
      const response = await request(app).get("/clientes").set("Authorization", `Bearer ${token}`)

      expect(response.status).toBe(200)
      expect(response.body.data).toBeDefined()
      expect(Array.isArray(response.body.data)).toBe(true)
    })
  })

  describe("Endpoint /produtos (público)", () => {
    test("GET /produtos deve funcionar sem autenticação", async () => {
      const response = await request(app).get("/produtos")

      expect(response.status).toBe(200)
      expect(response.body.data).toBeDefined()
      expect(Array.isArray(response.body.data)).toBe(true)
    })
  })

  describe("Autenticação", () => {
    test("POST /login com credenciais válidas", async () => {
      const response = await request(app).post("/login").send({
        usuario: "admin",
        senha: "123456",
      })

      expect(response.status).toBe(200)
      expect(response.body.token).toBeDefined()
      expect(response.body.message).toBe("Login realizado com sucesso")
    })

    test("POST /login com credenciais inválidas", async () => {
      const response = await request(app).post("/login").send({
        usuario: "admin",
        senha: "senha_errada",
      })

      expect(response.status).toBe(401)
      expect(response.body.error).toBe("Credenciais inválidas")
    })

    test("POST /logout deve funcionar", async () => {
      const response = await request(app).post("/logout").set("Authorization", `Bearer ${token}`)

      expect(response.status).toBe(200)
      expect(response.body.message).toBe("Logout realizado com sucesso")
    })
  })
})
