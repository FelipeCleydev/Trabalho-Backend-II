const request = require("supertest")
const app = require("../app")

describe("Validação de Campos", () => {
  describe("Validação de Clientes", () => {
    let token

    beforeAll(async () => {
      // Fazer login para obter token
      const loginResponse = await request(app).post("/login").send({
        usuario: "admin",
        senha: "123456",
      })
      token = loginResponse.body.token
    })

    test("Deve rejeitar nome com menos de 3 caracteres", async () => {
      const response = await request(app).post("/clientes").set("Authorization", `Bearer ${token}`).send({
        nome: "Jo",
        sobrenome: "Silva",
        email: "jo@email.com",
        idade: 25,
      })

      expect(response.status).toBe(400)
      expect(response.body.details).toContain("Nome deve ter entre 3 e 255 caracteres")
    })

    test("Deve rejeitar email inválido", async () => {
      const response = await request(app).post("/clientes").set("Authorization", `Bearer ${token}`).send({
        nome: "João",
        sobrenome: "Silva",
        email: "email-invalido",
        idade: 25,
      })

      expect(response.status).toBe(400)
      expect(response.body.details).toContain("Email deve ter formato válido")
    })

    test("Deve rejeitar idade inválida", async () => {
      const response = await request(app).post("/clientes").set("Authorization", `Bearer ${token}`).send({
        nome: "João",
        sobrenome: "Silva",
        email: "joao@email.com",
        idade: 150,
      })

      expect(response.status).toBe(400)
      expect(response.body.details).toContain("Idade deve ser maior que 0 e menor que 120")
    })
  })

  describe("Validação de Produtos", () => {
    test("Deve rejeitar preço negativo", async () => {
      const response = await request(app).post("/produtos").send({
        nome: "Produto Teste",
        descricao: "Descrição do produto",
        preco: -10.5,
        data_atualizado: "2024-01-15",
      })

      expect(response.status).toBe(400)
      expect(response.body.details).toContain("Preço deve ser positivo")
    })

    test("Deve rejeitar data fora do intervalo", async () => {
      const response = await request(app).post("/produtos").send({
        nome: "Produto Teste",
        descricao: "Descrição do produto",
        preco: 100.0,
        data_atualizado: "1999-12-31",
      })

      expect(response.status).toBe(400)
      expect(response.body.details).toContain("Data deve estar entre 01/01/2000 e 20/06/2025")
    })
  })
})
