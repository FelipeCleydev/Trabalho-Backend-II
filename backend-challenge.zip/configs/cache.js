const NodeCache = require("node-cache")

// Configurar cache com TTL de 30 segundos
const cache = new NodeCache({
  stdTTL: Number.parseInt(process.env.CACHE_TTL) || 30,
  checkperiod: 60,
  useClones: false,
})

// Eventos de cache para logging
cache.on("set", (key, value) => {
  console.log(`📦 Cache SET: ${key}`)
})

cache.on("del", (key, value) => {
  console.log(`🗑️  Cache DEL: ${key}`)
})

cache.on("expired", (key, value) => {
  console.log(`⏰ Cache EXPIRED: ${key}`)
})

module.exports = cache
