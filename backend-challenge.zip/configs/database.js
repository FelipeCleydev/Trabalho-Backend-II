const mysql = require("mysql2/promise")
require("dotenv").config()

const dbConfig = {
  host: process.env.DB_HOST || "localhost",
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "password",
  database: process.env.DB_NAME || "backend_challenge",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
}

// Criar pool de conexões
const pool = mysql.createPool(dbConfig)

// Função para testar conexão
async function testConnection() {
  try {
    const connection = await pool.getConnection()
    console.log("✅ Conectado ao banco de dados MySQL")
    connection.release()
    return true
  } catch (error) {
    console.error("❌ Erro ao conectar com o banco de dados:", error.message)
    return false
  }
}

// Testar conexão na inicialização
testConnection()

module.exports = pool
