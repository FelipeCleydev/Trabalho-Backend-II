const jwt = require("jsonwebtoken")
const usuarioService = require("../services/usuarioService")

class AuthController {
  async login(req, res) {
    try {
      const { usuario, senha } = req.body

      if (!usuario || !senha) {
        return res.status(400).json({
          error: "Dados obrigatórios",
          message: "Usuário e senha são obrigatórios",
        })
      }

      // Verificar credenciais
      const user = await usuarioService.findByCredentials(usuario, senha)

      if (!user) {
        return res.status(401).json({
          error: "Credenciais inválidas",
          message: "Usuário ou senha incorretos",
        })
      }

      // Gerar token JWT
      const token = jwt.sign(
        {
          userId: user.id,
          usuario: user.usuario,
        },
        process.env.JWT_SECRET,
        {
          expiresIn: process.env.JWT_EXPIRES_IN || "24h",
        },
      )

      // Salvar token no banco
      await usuarioService.updateToken(user.id, token)

      res.json({
        message: "Login realizado com sucesso",
        token,
        user: {
          id: user.id,
          usuario: user.usuario,
        },
        expiresIn: process.env.JWT_EXPIRES_IN || "24h",
      })
    } catch (error) {
      res.status(500).json({
        error: "Erro no login",
        message: error.message,
      })
    }
  }

  async logout(req, res) {
    try {
      const userId = req.user.id

      // Limpar token do banco
      await usuarioService.clearToken(userId)

      res.json({
        message: "Logout realizado com sucesso",
      })
    } catch (error) {
      res.status(500).json({
        error: "Erro no logout",
        message: error.message,
      })
    }
  }
}

module.exports = new AuthController()
