const clienteService = require("../services/clienteService")
const cache = require("../configs/cache")

class ClienteController {
  async getAll(req, res) {
    try {
      const cacheKey = "clientes_all"

      // Verificar cache primeiro
      const cachedData = cache.get(cacheKey)
      if (cachedData) {
        console.log("📦 Dados servidos do CACHE")
        return res.json({
          data: cachedData,
          source: "cache",
          timestamp: new Date().toISOString(),
        })
      }

      // Buscar no banco de dados
      console.log("🗄️  Dados servidos do BANCO DE DADOS")
      const clientes = await clienteService.getAll()

      // Salvar no cache
      cache.set(cacheKey, clientes)

      res.json({
        data: clientes,
        source: "database",
        timestamp: new Date().toISOString(),
      })
    } catch (error) {
      res.status(500).json({
        error: "Erro ao buscar clientes",
        message: error.message,
      })
    }
  }

  async getById(req, res) {
    try {
      const { id } = req.params
      const cliente = await clienteService.getById(id)

      if (!cliente) {
        return res.status(404).json({
          error: "Cliente não encontrado",
        })
      }

      res.json(cliente)
    } catch (error) {
      res.status(500).json({
        error: "Erro ao buscar cliente",
        message: error.message,
      })
    }
  }

  async create(req, res) {
    try {
      const cliente = await clienteService.create(req.body)

      // Invalidar cache
      cache.del("clientes_all")
      console.log("🗑️  Cache invalidado após criação")

      res.status(201).json({
        message: "Cliente criado com sucesso",
        data: cliente,
      })
    } catch (error) {
      if (error.message === "Email já cadastrado") {
        return res.status(409).json({
          error: "Conflito",
          message: error.message,
        })
      }

      res.status(500).json({
        error: "Erro ao criar cliente",
        message: error.message,
      })
    }
  }

  async update(req, res) {
    try {
      const { id } = req.params
      const cliente = await clienteService.update(id, req.body)

      // Invalidar cache
      cache.del("clientes_all")
      console.log("🗑️  Cache invalidado após atualização")

      res.json({
        message: "Cliente atualizado com sucesso",
        data: cliente,
      })
    } catch (error) {
      if (error.message === "Cliente não encontrado") {
        return res.status(404).json({
          error: "Cliente não encontrado",
        })
      }

      if (error.message === "Email já cadastrado") {
        return res.status(409).json({
          error: "Conflito",
          message: error.message,
        })
      }

      res.status(500).json({
        error: "Erro ao atualizar cliente",
        message: error.message,
      })
    }
  }

  async delete(req, res) {
    try {
      const { id } = req.params
      const cliente = await clienteService.delete(id)

      // Invalidar cache
      cache.del("clientes_all")
      console.log("🗑️  Cache invalidado após exclusão")

      res.json({
        message: "Cliente excluído com sucesso",
        data: cliente,
      })
    } catch (error) {
      if (error.message === "Cliente não encontrado") {
        return res.status(404).json({
          error: "Cliente não encontrado",
        })
      }

      res.status(500).json({
        error: "Erro ao excluir cliente",
        message: error.message,
      })
    }
  }
}

module.exports = new ClienteController()
