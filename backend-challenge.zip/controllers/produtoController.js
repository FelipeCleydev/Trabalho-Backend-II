const produtoService = require("../services/produtoService")

class ProdutoController {
  async getAll(req, res) {
    try {
      const produtos = await produtoService.getAll()
      res.json({
        data: produtos,
        timestamp: new Date().toISOString(),
      })
    } catch (error) {
      res.status(500).json({
        error: "Erro ao buscar produtos",
        message: error.message,
      })
    }
  }

  async getById(req, res) {
    try {
      const { id } = req.params
      const produto = await produtoService.getById(id)

      if (!produto) {
        return res.status(404).json({
          error: "Produto não encontrado",
        })
      }

      res.json(produto)
    } catch (error) {
      res.status(500).json({
        error: "Erro ao buscar produto",
        message: error.message,
      })
    }
  }

  async create(req, res) {
    try {
      const produto = await produtoService.create(req.body)

      res.status(201).json({
        message: "Produto criado com sucesso",
        data: produto,
      })
    } catch (error) {
      res.status(500).json({
        error: "Erro ao criar produto",
        message: error.message,
      })
    }
  }

  async update(req, res) {
    try {
      const { id } = req.params
      const produto = await produtoService.update(id, req.body)

      res.json({
        message: "Produto atualizado com sucesso",
        data: produto,
      })
    } catch (error) {
      if (error.message === "Produto não encontrado") {
        return res.status(404).json({
          error: "Produto não encontrado",
        })
      }

      res.status(500).json({
        error: "Erro ao atualizar produto",
        message: error.message,
      })
    }
  }

  async delete(req, res) {
    try {
      const { id } = req.params
      const produto = await produtoService.delete(id)

      res.json({
        message: "Produto excluído com sucesso",
        data: produto,
      })
    } catch (error) {
      if (error.message === "Produto não encontrado") {
        return res.status(404).json({
          error: "Produto não encontrado",
        })
      }

      res.status(500).json({
        error: "Erro ao excluir produto",
        message: error.message,
      })
    }
  }
}

module.exports = new ProdutoController()
