const usuarioService = require("../services/usuarioService")

class UsuarioController {
  async getAll(req, res) {
    try {
      const usuarios = await usuarioService.getAll()
      res.json({
        data: usuarios,
        timestamp: new Date().toISOString(),
      })
    } catch (error) {
      res.status(500).json({
        error: "Erro ao buscar usuários",
        message: error.message,
      })
    }
  }

  async getById(req, res) {
    try {
      const { id } = req.params
      const usuario = await usuarioService.getById(id)

      if (!usuario) {
        return res.status(404).json({
          error: "Usuário não encontrado",
        })
      }

      res.json(usuario)
    } catch (error) {
      res.status(500).json({
        error: "Erro ao buscar usuário",
        message: error.message,
      })
    }
  }

  async create(req, res) {
    try {
      const usuario = await usuarioService.create(req.body)

      res.status(201).json({
        message: "Usuário criado com sucesso",
        data: usuario,
      })
    } catch (error) {
      if (error.message === "Usuário já cadastrado") {
        return res.status(409).json({
          error: "Conflito",
          message: error.message,
        })
      }

      res.status(500).json({
        error: "Erro ao criar usuário",
        message: error.message,
      })
    }
  }
}

module.exports = new UsuarioController()
