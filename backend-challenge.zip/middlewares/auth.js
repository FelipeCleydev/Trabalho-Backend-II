const jwt = require("jsonwebtoken")
const db = require("../configs/database")

const authenticateToken = async (req, res, next) => {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1] // Bearer TOKEN

  if (!token) {
    return res.status(401).json({
      error: "Token de acesso requerido",
      message: "Você precisa estar logado para acessar este recurso",
    })
  }

  try {
    // Verificar se o token é válido
    const decoded = jwt.verify(token, process.env.JWT_SECRET)

    // Verificar se o token ainda está válido no banco
    const [rows] = await db.execute("SELECT id, usuario, token FROM usuarios WHERE id = ? AND token = ?", [
      decoded.userId,
      token,
    ])

    if (rows.length === 0) {
      return res.status(401).json({
        error: "Token inválido",
        message: "Token não encontrado ou foi invalidado",
      })
    }

    req.user = {
      id: decoded.userId,
      usuario: decoded.usuario,
    }

    next()
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        error: "Token expirado",
        message: "Faça login novamente",
      })
    }

    return res.status(403).json({
      error: "Token inválido",
      message: "Token malformado ou inválido",
    })
  }
}

module.exports = { authenticateToken }
