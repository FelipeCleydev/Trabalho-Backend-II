const validateCliente = (req, res, next) => {
  const { nome, sobrenome, email, idade } = req.body
  const errors = []

  // Validar nome
  if (!nome || nome.length < 3 || nome.length > 255) {
    errors.push("Nome deve ter entre 3 e 255 caracteres")
  }

  // Validar sobrenome
  if (!sobrenome || sobrenome.length < 3 || sobrenome.length > 255) {
    errors.push("Sobrenome deve ter entre 3 e 255 caracteres")
  }

  // Validar email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!email || !emailRegex.test(email)) {
    errors.push("Email deve ter formato válido")
  }

  // Validar idade
  if (!idade || idade <= 0 || idade >= 120) {
    errors.push("Idade deve ser maior que 0 e menor que 120")
  }

  if (errors.length > 0) {
    return res.status(400).json({
      error: "Dados inválidos",
      details: errors,
    })
  }

  next()
}

const validateProduto = (req, res, next) => {
  const { nome, descricao, preco, data_atualizado } = req.body
  const errors = []

  // Validar nome
  if (!nome || nome.length < 3 || nome.length > 255) {
    errors.push("Nome deve ter entre 3 e 255 caracteres")
  }

  // Validar descrição
  if (!descricao || descricao.length < 3 || descricao.length > 255) {
    errors.push("Descrição deve ter entre 3 e 255 caracteres")
  }

  // Validar preço
  if (!preco || preco <= 0) {
    errors.push("Preço deve ser positivo")
  }

  // Validar data_atualizado
  if (data_atualizado) {
    const date = new Date(data_atualizado)
    const minDate = new Date("2000-01-01")
    const maxDate = new Date("2025-06-20")

    if (date < minDate || date > maxDate) {
      errors.push("Data deve estar entre 01/01/2000 e 20/06/2025")
    }
  }

  if (errors.length > 0) {
    return res.status(400).json({
      error: "Dados inválidos",
      details: errors,
    })
  }

  next()
}

const validateUsuario = (req, res, next) => {
  const { usuario, senha } = req.body
  const errors = []

  // Validar usuário
  if (!usuario || usuario.length < 3 || usuario.length > 255) {
    errors.push("Usuário deve ter entre 3 e 255 caracteres")
  }

  // Validar senha
  if (!senha || senha.length < 6) {
    errors.push("Senha deve ter pelo menos 6 caracteres")
  }

  if (errors.length > 0) {
    return res.status(400).json({
      error: "Dados inválidos",
      details: errors,
    })
  }

  next()
}

module.exports = {
  validateCliente,
  validateProduto,
  validateUsuario,
}
