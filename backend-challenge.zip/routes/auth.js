const express = require("express")
const router = express.Router()
const authController = require("../controllers/authController")
const { authenticateToken } = require("../middlewares/auth")

// POST /login - Fazer login
router.post("/login", authController.login)

// POST /logout - Fazer logout (precisa estar autenticado)
router.post("/logout", authenticateToken, authController.logout)

module.exports = router
