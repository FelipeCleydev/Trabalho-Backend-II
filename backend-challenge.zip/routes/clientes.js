const express = require("express")
const router = express.Router()
const clienteController = require("../controllers/clienteController")
const { authenticateToken } = require("../middlewares/auth")
const { validateCliente } = require("../middlewares/validation")

// Todas as rotas de clientes precisam de autenticação
router.use(authenticateToken)

// GET /clientes - Listar todos os clientes (com cache)
router.get("/", clienteController.getAll)

// GET /clientes/:id - Buscar cliente por ID
router.get("/:id", clienteController.getById)

// POST /clientes - Criar novo cliente
router.post("/", validateCliente, clienteController.create)

// PUT /clientes/:id - Atualizar cliente
router.put("/:id", validateCliente, clienteController.update)

// DELETE /clientes/:id - Excluir cliente
router.delete("/:id", clienteController.delete)

module.exports = router
