const express = require("express")
const router = express.Router()
const produtoController = require("../controllers/produtoController")
const { validateProduto } = require("../middlewares/validation")

// GET /produtos - Listar todos os produtos (público)
router.get("/", produtoController.getAll)

// GET /produtos/:id - Buscar produto por ID (público)
router.get("/:id", produtoController.getById)

// POST /produtos - Criar novo produto (público)
router.post("/", validateProduto, produtoController.create)

// PUT /produtos/:id - Atualizar produto (público)
router.put("/:id", validateProduto, produtoController.update)

// DELETE /produtos/:id - Excluir produto (público)
router.delete("/:id", produtoController.delete)

module.exports = router
