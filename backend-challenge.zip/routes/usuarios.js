const express = require("express")
const router = express.Router()
const usuarioController = require("../controllers/usuarioController")
const { validateUsuario } = require("../middlewares/validation")

// GET /usuarios - Listar todos os usuários
router.get("/", usuarioController.getAll)

// GET /usuarios/:id - Buscar usuário por ID
router.get("/:id", usuarioController.getById)

// POST /usuarios - Criar novo usuário
router.post("/", validateUsuario, usuarioController.create)

module.exports = router
