const mysql = require("mysql2/promise")
const fs = require("fs").promises
const path = require("path")
require("dotenv").config()

async function setupDatabase() {
  let connection

  try {
    console.log("🔄 Configurando banco de dados...")

    // Conectar ao MySQL (sem especificar database)
    connection = await mysql.createConnection({
      host: process.env.DB_HOST || "localhost",
      port: process.env.DB_PORT || 3306,
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "password",
    })

    console.log("✅ Conectado ao MySQL")

    // Ler e executar schema.sql
    const schemaPath = path.join(__dirname, "..", "models", "schema.sql")
    const schemaSQL = await fs.readFile(schemaPath, "utf8")

    const schemaStatements = schemaSQL.split(";").filter((stmt) => stmt.trim())

    for (const statement of schemaStatements) {
      if (statement.trim()) {
        await connection.execute(statement)
      }
    }

    console.log("✅ Schema criado com sucesso")

    // Ler e executar seed.sql
    const seedPath = path.join(__dirname, "..", "models", "seed.sql")
    const seedSQL = await fs.readFile(seedPath, "utf8")

    const seedStatements = seedSQL.split(";").filter((stmt) => stmt.trim())

    for (const statement of seedStatements) {
      if (statement.trim()) {
        try {
          await connection.execute(statement)
        } catch (error) {
          // Ignorar erros de duplicação (dados já existem)
          if (!error.message.includes("Duplicate entry")) {
            throw error
          }
        }
      }
    }

    console.log("✅ Dados iniciais inseridos com sucesso")
    console.log("🎉 Banco de dados configurado completamente!")
  } catch (error) {
    console.error("❌ Erro ao configurar banco de dados:", error.message)
    process.exit(1)
  } finally {
    if (connection) {
      await connection.end()
    }
  }
}

// Executar se chamado diretamente
if (require.main === module) {
  setupDatabase()
}

module.exports = setupDatabase
