const db = require("../configs/database")

class ClienteService {
  async getAll() {
    const [rows] = await db.execute(
      "SELECT id, nome, sobrenome, email, idade, created_at, updated_at FROM clientes ORDER BY id DESC",
    )
    return rows
  }

  async getById(id) {
    const [rows] = await db.execute(
      "SELECT id, nome, sobrenome, email, idade, created_at, updated_at FROM clientes WHERE id = ?",
      [id],
    )
    return rows[0]
  }

  async create(clienteData) {
    const { nome, sobrenome, email, idade } = clienteData

    // Verificar se email já existe
    const [existing] = await db.execute("SELECT id FROM clientes WHERE email = ?", [email])

    if (existing.length > 0) {
      throw new Error("Email já cadastrado")
    }

    const [result] = await db.execute("INSERT INTO clientes (nome, sobrenome, email, idade) VALUES (?, ?, ?, ?)", [
      nome,
      sobrenome,
      email,
      idade,
    ])

    return this.getById(result.insertId)
  }

  async update(id, clienteData) {
    const { nome, sobrenome, email, idade } = clienteData

    // Verificar se cliente existe
    const existing = await this.getById(id)
    if (!existing) {
      throw new Error("Cliente não encontrado")
    }

    // Verificar se email já existe (exceto para o próprio cliente)
    const [emailCheck] = await db.execute("SELECT id FROM clientes WHERE email = ? AND id != ?", [email, id])

    if (emailCheck.length > 0) {
      throw new Error("Email já cadastrado")
    }

    await db.execute("UPDATE clientes SET nome = ?, sobrenome = ?, email = ?, idade = ? WHERE id = ?", [
      nome,
      sobrenome,
      email,
      idade,
      id,
    ])

    return this.getById(id)
  }

  async delete(id) {
    // Verificar se cliente existe
    const existing = await this.getById(id)
    if (!existing) {
      throw new Error("Cliente não encontrado")
    }

    await db.execute("DELETE FROM clientes WHERE id = ?", [id])
    return existing
  }
}

module.exports = new ClienteService()
