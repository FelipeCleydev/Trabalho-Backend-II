const db = require("../configs/database")

class ProdutoService {
  async getAll() {
    const [rows] = await db.execute(
      "SELECT id, nome, descricao, preco, data_atualizado, created_at, updated_at FROM produtos ORDER BY id DESC",
    )
    return rows
  }

  async getById(id) {
    const [rows] = await db.execute(
      "SELECT id, nome, descricao, preco, data_atualizado, created_at, updated_at FROM produtos WHERE id = ?",
      [id],
    )
    return rows[0]
  }

  async create(produtoData) {
    const { nome, descricao, preco, data_atualizado } = produtoData

    const dataAtualizada = data_atualizado || new Date()

    const [result] = await db.execute(
      "INSERT INTO produtos (nome, descricao, preco, data_atualizado) VALUES (?, ?, ?, ?)",
      [nome, descricao, preco, dataAtualizada],
    )

    return this.getById(result.insertId)
  }

  async update(id, produtoData) {
    const { nome, descricao, preco, data_atualizado } = produtoData

    // Verificar se produto existe
    const existing = await this.getById(id)
    if (!existing) {
      throw new Error("Produto não encontrado")
    }

    const dataAtualizada = data_atualizado || new Date()

    await db.execute("UPDATE produtos SET nome = ?, descricao = ?, preco = ?, data_atualizado = ? WHERE id = ?", [
      nome,
      descricao,
      preco,
      dataAtualizada,
      id,
    ])

    return this.getById(id)
  }

  async delete(id) {
    // Verificar se produto existe
    const existing = await this.getById(id)
    if (!existing) {
      throw new Error("Produto não encontrado")
    }

    await db.execute("DELETE FROM produtos WHERE id = ?", [id])
    return existing
  }
}

module.exports = new ProdutoService()
