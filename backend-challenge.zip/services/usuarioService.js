const db = require("../configs/database")
const bcrypt = require("bcryptjs")

class UsuarioService {
  async getAll() {
    const [rows] = await db.execute("SELECT id, usuario, created_at, updated_at FROM usuarios ORDER BY id DESC")
    return rows
  }

  async getById(id) {
    const [rows] = await db.execute("SELECT id, usuario, created_at, updated_at FROM usuarios WHERE id = ?", [id])
    return rows[0]
  }

  async create(usuarioData) {
    const { usuario, senha } = usuarioData

    // Verificar se usuário já existe
    const [existing] = await db.execute("SELECT id FROM usuarios WHERE usuario = ?", [usuario])

    if (existing.length > 0) {
      throw new Error("Usuário já cadastrado")
    }

    // Hash da senha
    const hashedPassword = await bcrypt.hash(senha, 10)

    const [result] = await db.execute("INSERT INTO usuarios (usuario, senha) VALUES (?, ?)", [usuario, hashedPassword])

    return this.getById(result.insertId)
  }

  async findByCredentials(usuario, senha) {
    const [rows] = await db.execute("SELECT id, usuario, senha FROM usuarios WHERE usuario = ?", [usuario])

    if (rows.length === 0) {
      return null
    }

    const user = rows[0]
    const isValidPassword = await bcrypt.compare(senha, user.senha)

    if (!isValidPassword) {
      return null
    }

    return {
      id: user.id,
      usuario: user.usuario,
    }
  }

  async updateToken(userId, token) {
    await db.execute("UPDATE usuarios SET token = ? WHERE id = ?", [token, userId])
  }

  async clearToken(userId) {
    await db.execute("UPDATE usuarios SET token = NULL WHERE id = ?", [userId])
  }
}

module.exports = new UsuarioService()
